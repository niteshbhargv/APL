/* @file snode.h
*@author Nitesh Bhargava CS12M032
*@brief  header file for the declaration of the snode class - smallest disk containing members as past and present node
*
* node class: 
* 	private members - previous and past node (prNode, paNode)
* 	public members - 
*		getprNode();
* 	        snode();
*	        setprNode(string);
*        	getpaNode();
*       	setpaNode(string);
*@date 20/08/12
*/
#include<iostream>
using namespace std;

class snode{

	string prNode;
	string paNode;
	
	public:
	snode();
	string getprNode();
	string getpaNode();
	void setprNode(string);
	void setpaNode(string);
};

