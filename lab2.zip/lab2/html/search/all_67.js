var searchData=
[
  ['getdata',['getData',['../classnode.html#a8f95b38d81b0186a3c71d1363fbbecb5',1,'node']]],
  ['getnext',['getNext',['../classnode.html#a25f5a5aab9c898327f740e8be385d02a',1,'node']]]
];
