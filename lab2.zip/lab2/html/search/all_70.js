var searchData=
[
  ['palindrome',['palindrome',['../classqueue_linked_list.html#ad7a0ad2819f0a3cc6f06db753294f061',1,'queueLinkedList']]]
];
