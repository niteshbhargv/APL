var searchData=
[
  ['setdata',['setData',['../classnode.html#a8b8ab5601fef58823309066f5f984deb',1,'node']]],
  ['setnext',['setNext',['../classnode.html#a75732eaa72ebfa08bfc50e7d1fed43fc',1,'node']]]
];
